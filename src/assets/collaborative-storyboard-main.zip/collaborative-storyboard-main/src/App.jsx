import React from 'react'
import Login from './components/Auth/Login'
import SignUp from './components/Auth/SignUp'
import GameInput from './components/pages/GameInput'
import GameStory from './components/pages/GameStory'
import Room from './components/pages/Room'
import ResetPassword from './components/pages/ResetPassword'

const App = () => {
  return (
    <div className='w-full bg-zinc-950'>
      {/* <Login /> */}
      <SignUp/>
      {/* <GameInput/> */}
      {/* <GameStory/> */}
      {/* <Room /> */}
      {/* <ResetPassword/> */}
    </div>
  )
}

export default App
