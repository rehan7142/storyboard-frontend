import React from 'react'

const GameStory = () => {
  return (
    <div className='h-screen story-board w-full px-20 py-15 text-6xl text-white font-semibold'>
      klj 
    </div>
  )
}

export default GameStory