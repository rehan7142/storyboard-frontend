import React from 'react'

const ResetPassword = () => {
  return (
    <div className='h-screen w-full bg-zinc-950 flex items-center justify-center'>
        <div className='h-fit w-[30%] bg-zinc-800 rounded-2xl flex flex-col items-center text-white py-[2%]'>
            <p className='text-[1.5vw] font-medium'>Reset Password OTP</p>
            <p className='text-[1vw] font-medium text-gray-600 mt-2'>Enter the 6 digit code sent to your email id</p>
            <div className='flex gap-1 mt-5'>
                <input inputmode="numeric" maxlength="6" type="text" class="w-full border-2 border-gray-200 outline-none rounded-lg text-center text-white py-2" autocomplete="off" accesskey="0"/>
            </div>
            <button className='mt-4 bg-gradient-to-r from-[blue] to-[darkblue] py-3 px-20 outline-none rounded-full text-[1.2vw] font-medium'>Submit</button>
        </div>
    </div>
  )
}

export default ResetPassword